const wrapper = document.querySelector('.wrapper')
const registerLink = document.querySelector('.register-link')
const loginLink = document.querySelector('.login-link')

registerLink.onclick = () => {
    wrapper.classList.add('active')
}

loginLink.onclick = () => {
    wrapper.classList.remove('active')
	// Handle the login form submission
	document.getElementById("loginForm").addEventListener("submit", function (event) {
	    event.preventDefault(); // Prevent the form from submitting
	    window.location.href = "dashboard.html"; // Redirect to dashboard.html
	});

}