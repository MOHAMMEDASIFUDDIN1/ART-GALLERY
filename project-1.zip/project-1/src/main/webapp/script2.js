let cartItems = JSON.parse(localStorage.getItem('cart')) || [];

function addToCart() {
    const item = {
        name: "Abstract Painting 1", // You can dynamically get the name and price based on the artwork being clicked
        price: 500
    };

    cartItems.push(item);
    localStorage.setItem('cart', JSON.stringify(cartItems)); // Save the updated cart to localStorage

    cartCount++;
    document.getElementById('cart').innerHTML = `Cart (${cartItems.length})`; // Update cart display
}
