package klu.model;

public class CaptchaUtil {

}
